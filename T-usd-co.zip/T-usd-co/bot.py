import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
import asyncio
import ccxt
from datetime import datetime
import config
from analysis.technical import TechnicalAnalyzer
from analysis.news import NewsAnalyzer
from analysis.signals import SignalGenerator
from utils.performance import PerformanceTracker
from utils.helpers import format_signal_message
import numpy as np
from shared_context import app

# Setup logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

class TradingBot:
    def __init__(self):
        with app.app_context():
            self.exchange = ccxt.binance()
            self.technical_analyzer = TechnicalAnalyzer()
            self.news_analyzer = NewsAnalyzer()
            self.signal_generator = SignalGenerator()
            self.performance_tracker = PerformanceTracker()
            self.subscribers = set()  # Store subscriber chat IDs

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        keyboard = [
            [InlineKeyboardButton("احصل على إشارة", callback_data='signal'),
             InlineKeyboardButton("الأداء", callback_data='performance')],
            [InlineKeyboardButton("اشترك في الإشارات", callback_data='subscribe'),
             InlineKeyboardButton("إلغاء الاشتراك", callback_data='unsubscribe')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(
            'مرحباً بك في بوت تحليل العملات الرقمية! \n'
            'اختر من القائمة أدناه:',
            reply_markup=reply_markup
        )

    async def button_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()

        chat_id = update.effective_chat.id

        if query.data == 'signal':
            signals = await self.generate_signals()
            await query.message.reply_text(signals)
        elif query.data == 'performance':
            with app.app_context():
                performance = self.performance_tracker.get_performance_report()
            await query.message.reply_text(performance)
        elif query.data == 'subscribe':
            self.subscribers.add(chat_id)
            await query.message.reply_text("تم الاشتراك في إشارات التداول التلقائية ✅")
        elif query.data == 'unsubscribe':
            self.subscribers.remove(chat_id)
            await query.message.reply_text("تم إلغاء الاشتراك من إشارات التداول التلقائية ❌")

    async def generate_signals(self):
        with app.app_context():
            signals = []
            for pair in config.TRADING_PAIRS:
                try:
                    # Get price data
                    ohlcv = self.exchange.fetch_ohlcv(pair, timeframe='1h', limit=100)

                    # Perform technical analysis
                    technical_signal = self.technical_analyzer.analyze(ohlcv)

                    # Get technical indicators
                    closes = np.array([x[4] for x in ohlcv])
                    technical_indicators = {
                        'rsi': self.technical_analyzer.calculate_rsi(closes),
                        'macd': self.technical_analyzer.calculate_macd(closes)[0],
                        'signal': self.technical_analyzer.calculate_macd(closes)[1],
                        'ma_short': self.technical_analyzer.calculate_moving_averages(closes)[0],
                        'ma_long': self.technical_analyzer.calculate_moving_averages(closes)[1],
                        'upper_bb': self.technical_analyzer.calculate_bollinger_bands(closes)[0],
                        'lower_bb': self.technical_analyzer.calculate_bollinger_bands(closes)[2]
                    }

                    # Get news sentiment
                    news_sentiment = await self.news_analyzer.get_sentiment(pair)

                    # Generate signal with technical indicators and symbol-specific settings
                    signal = self.signal_generator.generate_signal(
                        technical_signal, 
                        news_sentiment,
                        technical_indicators,
                        symbol=pair
                    )
                    signals.append(format_signal_message(pair, signal))
                except Exception as e:
                    logger.error(f"Error generating signal for {pair}: {str(e)}")
                    continue

            return "\n\n".join(signals) if signals else "لا توجد إشارات متاحة حالياً"

    async def send_periodic_signals(self, context: ContextTypes.DEFAULT_TYPE):
        signals = await self.generate_signals()
        for chat_id in self.subscribers:
            try:
                await context.bot.send_message(chat_id=chat_id, text=signals)
            except Exception as e:
                logger.error(f"Error sending signal to {chat_id}: {str(e)}")

def main():
    with app.app_context():
        # Create bot instance
        bot = TradingBot()

        # Initialize the Application
        application = Application.builder().token(config.TELEGRAM_BOT_TOKEN).build()

        # Add handlers
        application.add_handler(CommandHandler("start", bot.start))
        application.add_handler(CallbackQueryHandler(bot.button_callback))

        # Add periodic jobs
        application.job_queue.run_repeating(bot.send_periodic_signals, interval=3600)  # Every hour

        # Start the bot
        application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()