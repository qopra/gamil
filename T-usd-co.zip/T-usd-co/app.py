import os
from flask import render_template, jsonify
from shared_context import app, db
from analysis.technical import TechnicalAnalyzer
from analysis.news import NewsAnalyzer
from analysis.signals import SignalGenerator
import numpy as np
from datetime import datetime, timedelta
import ccxt
import logging

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.ERROR)

def init_analyzers():
    """Initialize analyzers within app context"""
    global technical_analyzer, news_analyzer, signal_generator, exchange
    try:
        technical_analyzer = TechnicalAnalyzer()
        news_analyzer = NewsAnalyzer()
        signal_generator = SignalGenerator()

        # Train ML model after initialization
        signal_generator.ml_optimizer.train_model()

        exchange = ccxt.binance()
        logger.info("All analyzers initialized successfully")
    except Exception as e:
        logger.error(f"Error initializing analyzers: {str(e)}")
        raise

@app.route('/')
def index():
    return render_template('charts.html')

@app.route('/charts')
def charts():
    return render_template('charts.html')

@app.route('/api/chart-data/<symbol>')
async def chart_data(symbol):
    try:
        # Decode the symbol from URL
        symbol = symbol.replace('%2F', '/')  # Replace URL-encoded forward slash
        logger.info(f"Fetching chart data for symbol: {symbol}")

        # Fetch historical data
        ohlcv = exchange.fetch_ohlcv(symbol, timeframe='1h', limit=100)
        if not ohlcv:
            logger.error(f"No OHLCV data received for {symbol}")
            return jsonify({'error': 'No data available'}), 404

        # Process data for charts
        timestamps = [datetime.fromtimestamp(x[0]/1000).strftime('%Y-%m-%d %H:%M') for x in ohlcv]
        prices = [x[4] for x in ohlcv]
        logger.info(f"Retrieved {len(prices)} price points for {symbol}")

        # Calculate technical indicators
        closes = np.array(prices)

        # Technical Analysis with error handling
        try:
            rsi = [technical_analyzer.calculate_rsi(closes[:i+1]) if i >= 14 else None for i in range(len(closes))]
            macd, signal = zip(*[technical_analyzer.calculate_macd(closes[:i+1]) if i >= 26 else (None, None) for i in range(len(closes))])
            ma_short, ma_long = zip(*[technical_analyzer.calculate_moving_averages(closes[:i+1]) if i >= 50 else (None, None) for i in range(len(closes))])

            # Calculate Bollinger Bands
            bb_upper = []
            bb_lower = []
            for i in range(len(closes)):
                if i >= 20:
                    upper, _, lower = technical_analyzer.calculate_bollinger_bands(closes[:i+1])
                    bb_upper.append(upper)
                    bb_lower.append(lower)
                else:
                    bb_upper.append(None)
                    bb_lower.append(None)
        except Exception as e:
            logger.error(f"Error calculating technical indicators: {str(e)}")
            return jsonify({'error': 'Error calculating indicators'}), 500

        # Get current signals
        technical_signals = technical_analyzer.analyze(ohlcv)
        news_sentiment = await news_analyzer.get_sentiment(symbol)

        # Generate signal with technical indicators
        current_indicators = {
            'rsi': rsi[-1],
            'macd': macd[-1],
            'signal': signal[-1],
            'ma_short': ma_short[-1],
            'ma_long': ma_long[-1],
            'current_price': prices[-1],
            'bb_upper': bb_upper[-1],
            'bb_lower': bb_lower[-1]
        }

        signal = signal_generator.generate_signal(
            technical_signals,
            news_sentiment,
            current_indicators,
            symbol
        )

        # Format signals for display
        formatted_signals = [{
            'direction': signal['direction'],
            'strength': signal['strength'],
            'confidence': signal['confidence'],
            'target_price': signal.get('target_price'),
            'stop_loss': signal.get('stop_loss'),
            'timestamp': datetime.now().isoformat(),
            'reasons': signal.get('reasons', [])
        }]

        return jsonify({
            'timestamps': timestamps,
            'prices': prices,
            'rsi': rsi,
            'macd': macd,
            'signal': signal,
            'ma_short': ma_short,
            'ma_long': ma_long,
            'bb_upper': bb_upper,
            'bb_lower': bb_lower,
            'signals': formatted_signals
        })

    except Exception as e:
        logger.error(f"Error generating chart data for {symbol}: {str(e)}")
        return jsonify({'error': str(e)}), 500

def main():
    with app.app_context():
        db.create_all()
        init_analyzers()
        app.run(host='0.0.0.0', port=5000, debug=True)

if __name__ == '__main__':
    main()