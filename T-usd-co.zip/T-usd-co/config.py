import os

# Configuration settings for the bot
TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN')  # Get token from environment
NEWS_API_KEY = os.environ.get('NEWS_API_KEY')     # Get API key from environment

# Trading parameters - تحسين أزواج التداول والإطارات الزمنية
TRADING_PAIRS = ['BTC/USDT', 'ETH/USDT', 'BNB/USDT']
TIMEFRAMES = {
    '1h': '1 hour',
    '4h': '4 hours',
    '1d': '1 day'
}
DEFAULT_TIMEFRAME = '1h'

# Technical Analysis Parameters - تحسين معايير التحليل الفني
RSI_PERIOD = 14
RSI_OVERBOUGHT = 75  # زيادة من 70 للحصول على إشارات أقوى
RSI_OVERSOLD = 25    # خفض من 30 للحصول على إشارات أقوى
MA_SHORT = 20
MA_LONG = 50

# Take Profit and Stop Loss settings - تحسين نسب الربح والخسارة
DEFAULT_TAKE_PROFIT = 3.0  # زيادة من 2% إلى 3%
DEFAULT_STOP_LOSS = 1.5    # زيادة من 1% إلى 1.5%

# News Analysis Parameters - تحسين معايير تحليل الأخبار
NEWS_UPDATE_INTERVAL = 1800  # تخفيض من 3600 إلى 1800 ثانية
NEWS_KEYWORDS = [
    'bitcoin', 'crypto', 'blockchain', 'cryptocurrency',
    'ethereum', 'binance', 'market', 'trading',
    'bull', 'bear', 'rally', 'dump'  # إضافة كلمات مفتاحية جديدة
]
NEWS_SENTIMENT_THRESHOLD = 0.25  # تخفيض من 0.3 لزيادة الحساسية

# Performance Tracking - تحسين تتبع الأداء
PERFORMANCE_REPORT_HOUR = 0  # Daily report at midnight UTC
BACKTEST_DAYS = 30  # Number of days for backtesting

# Signal Settings - تحسين إعدادات الإشارات
SIGNAL_MIN_STRENGTH = 2.5  # زيادة من 2 إلى 2.5 للحصول على إشارات أقوى
SIGNAL_UPDATE_INTERVAL = 1800  # تخفيض من 3600 إلى 1800 ثانية

# Debug Mode
DEBUG = False  # Set to True to enable debug logging

# Trading Time Windows - إضافة نوافذ زمنية للتداول
TRADING_HOURS = {
    'optimal': range(18, 23),  # 18:00-22:00
    'good': range(13, 18),     # 13:00-17:00
    'avoid': range(0, 7)       # 00:00-06:00
}

TRADING_DAYS = {
    'optimal': ['Friday', 'Thursday', 'Sunday'],
    'avoid': ['Saturday']
}

# Pair-specific settings - إعدادات خاصة لكل زوج
PAIR_SETTINGS = {
    'BTC/USDT': {
        'min_profit': 2.5,
        'max_loss': 1.2,
        'confidence_threshold': 0.65
    },
    'ETH/USDT': {
        'min_profit': 3.0,
        'max_loss': 1.5,
        'confidence_threshold': 0.70
    },
    'BNB/USDT': {
        'min_profit': 2.8,
        'max_loss': 1.3,
        'confidence_threshold': 0.68
    }
}