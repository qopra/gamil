import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_assets import Environment, Bundle

# Initialize Flask app
app = Flask(__name__)

# Configure database
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize database
db = SQLAlchemy()
db.init_app(app)

# Initialize assets after app is created
assets = Environment(app)
assets.url = app.static_url_path
scss = Bundle('css/style.css', filters='cssmin', output='css/style.min.css')
js = Bundle('js/charts.js', filters='jsmin', output='js/charts.min.js')
assets.register('scss_all', scss)
assets.register('js_all', js)

# Create application context
with app.app_context():
    db.create_all()