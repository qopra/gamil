let priceChart = null;
let indicatorsChart = null;

async function fetchChartData(symbol) {
    try {
        // Encode the symbol for the URL
        const encodedSymbol = encodeURIComponent(symbol);
        const response = await fetch(`/api/chart-data/${encodedSymbol}`);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching chart data:', error);
        return null;
    }
}

function createPriceChart(data) {
    const ctx = document.getElementById('priceChart').getContext('2d');

    if (priceChart) {
        priceChart.destroy();
    }

    // Add Bollinger Bands
    priceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.timestamps,
            datasets: [
                {
                    label: 'السعر',
                    data: data.prices,
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1,
                    fill: false,
                    order: 1
                },
                {
                    label: 'المتوسط المتحرك القصير',
                    data: data.ma_short,
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderDash: [5, 5],
                    fill: false,
                    order: 2
                },
                {
                    label: 'المتوسط المتحرك الطويل',
                    data: data.ma_long,
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderDash: [5, 5],
                    fill: false,
                    order: 3
                },
                {
                    label: 'Bollinger Upper',
                    data: data.bb_upper,
                    borderColor: 'rgba(128, 128, 128, 0.5)',
                    fill: false,
                    order: 4
                },
                {
                    label: 'Bollinger Lower',
                    data: data.bb_lower,
                    borderColor: 'rgba(128, 128, 128, 0.5)',
                    fill: '+1',
                    backgroundColor: 'rgba(128, 128, 128, 0.1)',
                    order: 5
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                intersect: false,
                mode: 'index'
            },
            plugins: {
                title: {
                    display: true,
                    text: 'تحليل السعر والمؤشرات الفنية',
                    font: {
                        size: 16
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'التاريخ'
                    }
                },
                y: {
                    display: true,
                    title: {
                        display: true,
                        text: 'السعر'
                    }
                }
            }
        }
    });
}

function createIndicatorsChart(data) {
    const ctx = document.getElementById('indicatorsChart').getContext('2d');

    if (indicatorsChart) {
        indicatorsChart.destroy();
    }

    indicatorsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.timestamps,
            datasets: [
                {
                    label: 'RSI',
                    data: data.rsi,
                    borderColor: 'rgb(255, 99, 132)',
                    yAxisID: 'y1',
                    fill: false
                },
                {
                    label: 'MACD',
                    data: data.macd,
                    borderColor: 'rgb(54, 162, 235)',
                    yAxisID: 'y2',
                    fill: false
                },
                {
                    label: 'Signal Line',
                    data: data.signal,
                    borderColor: 'rgb(255, 159, 64)',
                    yAxisID: 'y2',
                    borderDash: [5, 5],
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                intersect: false,
                mode: 'index'
            },
            plugins: {
                title: {
                    display: true,
                    text: 'المؤشرات الفنية',
                    font: {
                        size: 16
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'RSI'
                    },
                    min: 0,
                    max: 100,
                    grid: {
                        color: 'rgba(255, 99, 132, 0.2)'
                    }
                },
                y2: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'MACD'
                    },
                    grid: {
                        drawOnChartArea: false
                    }
                }
            }
        }
    });
}

function updateSignalsList(signals) {
    const signalsList = document.getElementById('signalsList');
    signalsList.innerHTML = signals.map(signal => `
        <div class="signal-item signal-${signal.direction.toLowerCase()}">
            <div class="d-flex justify-content-between align-items-center">
                <strong>${signal.direction === 'BUY' ? '🟢 شراء' : signal.direction === 'SELL' ? '🔴 بيع' : '⚪ محايد'}</strong>
                <small>${new Date(signal.timestamp).toLocaleString('ar-SA')}</small>
            </div>
            <div class="mt-2">
                <div>💪 القوة: ${'🔥'.repeat(Math.round(signal.strength))}</div>
                <div>📊 الثقة: ${signal.confidence.toFixed(1)}%</div>
                ${signal.target_price ? `<div>🎯 الهدف: ${signal.target_price.toFixed(2)}</div>` : ''}
                ${signal.stop_loss ? `<div>🛑 وقف الخسارة: ${signal.stop_loss.toFixed(2)}</div>` : ''}
            </div>
        </div>
    `).join('');
}

async function updateCharts() {
    const symbol = document.getElementById('symbolSelector').value;
    const data = await fetchChartData(symbol);

    if (data) {
        createPriceChart(data);
        createIndicatorsChart(data);
        updateSignalsList(data.signals);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    updateCharts();
    document.getElementById('symbolSelector').addEventListener('change', updateCharts);

    // تحديث البيانات كل دقيقة
    setInterval(updateCharts, 60000);
});