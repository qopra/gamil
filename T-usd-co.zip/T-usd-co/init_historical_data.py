from datetime import datetime, timedelta
import random
from models import db, Signal, Trade, AccountBalance
from app import app
import config

def generate_historical_data():
    start_date = datetime(2025, 1, 1)
    end_date = datetime(2025, 2, 9)  # اليوم
    symbols = config.TRADING_PAIRS
    initial_balance = 200.0  # رأس المال الأولي
    current_balance = initial_balance

    # تحديد نطاقات الأسعار لكل عملة
    price_ranges = {
        'BTC/USDT': (40000, 50000),
        'ETH/USDT': (2500, 3000),
        'BNB/USDT': (250, 300)
    }

    # مسح البيانات القديمة
    AccountBalance.query.delete()
    Trade.query.delete()
    Signal.query.delete()

    # إضافة رصيد البداية
    initial_balance_record = AccountBalance(
        timestamp=start_date,
        balance=initial_balance,
        change=initial_balance,
        change_type='initial'
    )
    db.session.add(initial_balance_record)

    current_date = start_date
    consecutive_losses = 0  # تتبع الخسائر المتتالية

    while current_date < end_date:
        # تعديل عدد الإشارات اليومية
        daily_signals = random.randint(2, 4)

        for _ in range(daily_signals):
            hour = random.randint(0, 23)
            is_optimal_time = hour in range(18, 23)
            is_good_time = hour in range(13, 18)

            current_day = current_date.strftime('%A')
            is_optimal_day = current_day in config.TRADING_DAYS['optimal']
            is_avoid_day = current_day in config.TRADING_DAYS['avoid']

            # تحسين احتمالية النجاح في الأوقات المثالية
            base_win_probability = 0.55  # احتمالية أساسية

            # تعديل احتمالية النجاح حسب الظروف
            if consecutive_losses > 2:
                base_win_probability *= 1.2  # زيادة فرص النجاح بعد خسائر متتالية

            # تعديل الاحتمالية حسب الوقت
            if is_optimal_time and is_optimal_day:
                win_probability = base_win_probability * 1.8  # زيادة كبيرة للأوقات المثالية
            elif is_good_time and not is_avoid_day:
                win_probability = base_win_probability * 1.3
            elif hour >= 0 and hour <= 6:
                win_probability = base_win_probability * 0.7
            elif is_avoid_day:
                win_probability = base_win_probability * 0.6
            else:
                win_probability = base_win_probability

            # حساب حجم الصفقة الأساسي
            base_position_size = current_balance * 0.15  # 15% من الرصيد كأساس

            # تعديل حجم الصفقة حسب الظروف
            position_multiplier = 1.0
            if consecutive_losses > 2:
                position_multiplier *= 0.7  # تقليل المخاطر بعد الخسائر
            if is_optimal_time and is_optimal_day:
                position_multiplier *= 1.3  # زيادة في الأوقات المثالية
            elif is_avoid_day or (hour >= 0 and hour <= 6):
                position_multiplier *= 0.5  # تخفيض كبير في الأوقات عالية المخاطر

            position_size = base_position_size * position_multiplier

            # اختيار العملة
            symbol = random.choice(symbols)

            signal_type = random.choice(['BUY', 'SELL'])
            min_price, max_price = price_ranges[symbol]
            entry_price = random.uniform(min_price, max_price)

            # إنشاء إشارة
            signal = Signal(
                symbol=symbol,
                signal_type=signal_type,
                entry_price=entry_price,
                timestamp=current_date + timedelta(hours=hour),
                status='closed'
            )
            db.session.add(signal)
            db.session.flush()

            # تحديد نتيجة الصفقة مع مراعاة الاحتمالية المحسنة
            is_winning = random.random() < win_probability

            # تحديد نسب الربح والخسارة بشكل أكثر واقعية
            if is_winning:
                if is_optimal_time and is_optimal_day:
                    profit_pct = random.uniform(3.0, 5.0)  # أرباح معقولة في الأوقات المثالية
                elif is_good_time and not is_avoid_day:
                    profit_pct = random.uniform(2.0, 4.0)
                else:
                    profit_pct = random.uniform(1.5, 3.0)
            else:
                if consecutive_losses > 2:
                    profit_pct = random.uniform(-1.5, -0.8)  # تقليل الخسائر بعد خسائر متتالية
                elif is_avoid_day:
                    profit_pct = random.uniform(-2.0, -1.2)
                else:
                    profit_pct = random.uniform(-1.8, -0.8)

            if signal_type == 'SELL':
                profit_pct = -profit_pct

            exit_price = entry_price * (1 + (profit_pct/100))
            profit_amount = position_size * (profit_pct/100)

            # تحديث عداد الخسائر المتتالية
            if profit_amount > 0:
                consecutive_losses = 0
            else:
                consecutive_losses += 1

            # إنشاء الصفقة
            trade = Trade(
                signal_id=signal.id,
                symbol=symbol,
                entry_price=entry_price,
                exit_price=exit_price,
                position_size=position_size,
                profit_percentage=profit_pct,
                profit_amount=profit_amount,
                entry_time=signal.timestamp,
                exit_time=signal.timestamp + timedelta(hours=random.randint(1, 4))  # صفقات أقصر
            )
            db.session.add(trade)

            # تحديث رصيد الحساب
            current_balance += profit_amount
            balance_update = AccountBalance(
                timestamp=trade.exit_time,
                balance=current_balance,
                change=profit_amount,
                change_type='profit' if profit_amount > 0 else 'loss',
                trade_id=trade.id
            )
            db.session.add(balance_update)

        current_date += timedelta(days=1)

    db.session.commit()
    print("تم إنشاء البيانات التاريخية بنجاح")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        generate_historical_data()