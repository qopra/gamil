from analysis.ml_optimizer import MLOptimizer
from datetime import datetime
import config

class SignalGenerator:
    def __init__(self):
        self.last_signals = {}
        # تحديث الأوزان بناءً على التحليل الجديد
        self.indicator_weights = {
            'RSI': 1.5,    # زيادة أكبر لوزن RSI
            'MA': 1.3,     # زيادة وزن المتوسطات
            'MACD': 1.6,   # زيادة وزن MACD
            'BB': 0.7,     # تخفيض أكبر لوزن البولنجر
            'NEWS': 1.2    # زيادة وزن الأخبار
        }
        # تحسين الأوزان لكل زوج بناءً على الأداء
        self.pair_weights = {
            'BTC/USDT': {
                'RSI': 1.6,   # زيادة كبيرة بناءً على الأداء الممتاز
                'MA': 1.3,
                'MACD': 1.6,
                'BB': 0.7,
                'NEWS': 1.2
            },
            'ETH/USDT': {
                'RSI': 1.5,
                'MA': 1.4,    # زيادة للمتوسطات في ETH
                'MACD': 1.5,
                'BB': 0.6,    # تخفيض أكبر للتقلبات
                'NEWS': 1.3   # زيادة تأثير الأخبار
            },
            'BNB/USDT': {
                'RSI': 1.4,
                'MA': 1.2,
                'MACD': 1.5,
                'BB': 0.7,
                'NEWS': 1.1
            }
        }
        self.ml_optimizer = MLOptimizer()
        # Don't train immediately, wait for proper initialization

    def get_time_multiplier(self, current_hour, current_day):
        """حساب مضاعف الوقت بناءً على الساعة واليوم"""
        time_multiplier = 1.0

        # التحقق من الوقت المثالي
        if current_hour in config.TRADING_HOURS['optimal']:
            time_multiplier *= 1.3  # زيادة من 1.2
        elif current_hour in config.TRADING_HOURS['avoid']:
            time_multiplier *= 0.5  # تخفيض من 0.8
        elif current_hour in config.TRADING_HOURS['good']:
            time_multiplier *= 1.1  # إضافة مستوى متوسط

        # التحقق من اليوم
        if current_day in config.TRADING_DAYS['optimal']:
            time_multiplier *= 1.2
        elif current_day in config.TRADING_DAYS['avoid']:
            time_multiplier *= 0.4  # تخفيض أكبر للأيام عالية المخاطر

        return time_multiplier

    def calculate_target_prices(self, current_price, symbol, signal_type):
        """حساب أهداف الربح ووقف الخسارة الديناميكي"""
        settings = config.PAIR_SETTINGS[symbol]

        if signal_type == "BUY":
            take_profit = current_price * (1 + settings['min_profit'] / 100)
            stop_loss = current_price * (1 - settings['max_loss'] / 100)
        else:
            take_profit = current_price * (1 - settings['min_profit'] / 100)
            stop_loss = current_price * (1 + settings['max_loss'] / 100)

        return take_profit, stop_loss

    def generate_signal(self, technical_signals, news_sentiment, technical_indicators=None, symbol=None):
        current_hour = datetime.now().hour
        current_day = datetime.now().strftime('%A')

        # الحصول على مضاعف الوقت المحسن
        time_multiplier = self.get_time_multiplier(current_hour, current_day)

        signal_strength = 0
        signal_reasons = []
        buy_signals = 0
        sell_signals = 0

        # اختيار الأوزان المناسبة حسب العملة
        weights = self.pair_weights.get(symbol, self.indicator_weights)

        # معالجة الإشارات الفنية مع الأوزان المحسنة
        for indicator, direction, reason in technical_signals:
            weight = weights.get(indicator, 1.0) * time_multiplier
            if direction == "BUY":
                buy_signals += weight
                signal_strength += weight
            elif direction == "SELL":
                sell_signals += weight
                signal_strength -= weight
            signal_reasons.append(reason)

        # معالجة تحليل الأخبار مع الوزن المحسن
        news_weight = weights['NEWS'] * time_multiplier
        if abs(news_sentiment) > config.NEWS_SENTIMENT_THRESHOLD:
            if news_sentiment > 0:
                signal_strength += news_weight * 1.2  # زيادة تأثير الأخبار الإيجابية
                buy_signals += news_weight
                signal_reasons.append(f"الأخبار إيجابية جداً: {news_sentiment:.2f}")
            else:
                signal_strength -= news_weight * 1.2
                sell_signals += news_weight
                signal_reasons.append(f"الأخبار سلبية جداً: {news_sentiment:.2f}")

        # حساب ثقة الإشارة
        total_signals = buy_signals + sell_signals
        buy_confidence = (buy_signals / total_signals) * 100 if total_signals > 0 else 0
        sell_confidence = (sell_signals / total_signals) * 100 if total_signals > 0 else 0

        # عتبات محسنة حسب العملة والوقت
        min_strength = config.SIGNAL_MIN_STRENGTH * (
            1.2 if current_day in config.TRADING_DAYS['optimal'] else
            1.5 if current_day in config.TRADING_DAYS['avoid'] else 1.0
        )

        # توليد الإشارة النهائية مع أهداف ديناميكية
        signal = None
        current_price = technical_indicators.get('current_price', 0) if technical_indicators else 0

        if signal_strength >= min_strength:
            take_profit, stop_loss = self.calculate_target_prices(current_price, symbol, "BUY")
            signal = {
                'direction': 'BUY',
                'strength': abs(signal_strength),
                'confidence': buy_confidence,
                'target_price': take_profit,
                'stop_loss': stop_loss,
                'reasons': signal_reasons
            }

        elif signal_strength <= -min_strength:
            take_profit, stop_loss = self.calculate_target_prices(current_price, symbol, "SELL")
            signal = {
                'direction': 'SELL',
                'strength': abs(signal_strength),
                'confidence': sell_confidence,
                'target_price': take_profit,
                'stop_loss': stop_loss,
                'reasons': signal_reasons
            }

        # إضافة معلومات الوقت
        if signal:
            if current_hour in config.TRADING_HOURS['optimal']:
                signal_reasons.append("⭐ وقت مثالي للتداول")
            elif current_hour in config.TRADING_HOURS['good']:
                signal_reasons.append("✅ وقت جيد للتداول")

            if current_day in config.TRADING_DAYS['optimal']:
                signal_reasons.append("📅 يوم مفضل للتداول")

        # تحقق من النموذج للتأكد من صحة الإشارة
        if signal and technical_indicators:
            ml_features = self.ml_optimizer.prepare_features(signal, technical_indicators)
            success_probability = self.ml_optimizer.predict_success(ml_features)

            # استخدام عتبات الثقة المخصصة لكل عملة
            min_probability = config.PAIR_SETTINGS[symbol]['confidence_threshold']

            signal['confidence'] = success_probability * 100
            signal['reasons'].append(f"احتمالية النجاح وفقاً للتعلم الآلي: {success_probability:.1%}")

            if success_probability < min_probability:
                return {
                    'direction': 'NEUTRAL',
                    'strength': 0,
                    'confidence': 0,
                    'reasons': ['تم إلغاء الإشارة بسبب احتمالية نجاح منخفضة وفقاً للتعلم الآلي']
                }

        return signal or {
            'direction': 'NEUTRAL',
            'strength': 0,
            'confidence': 0,
            'reasons': ['لا توجد إشارة قوية في الوقت الحالي']
        }