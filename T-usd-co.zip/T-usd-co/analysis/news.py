from newsapi import NewsApiClient
import asyncio
from config import NEWS_API_KEY, NEWS_KEYWORDS
import time

class NewsAnalyzer:
    def __init__(self):
        self.newsapi = NewsApiClient(api_key=NEWS_API_KEY)
        self.cache = {}
        self.cache_duration = 3600  # 1 hour

    async def get_sentiment(self, symbol):
        """Get news sentiment asynchronously"""
        # Check cache first
        if symbol in self.cache:
            timestamp, sentiment = self.cache[symbol]
            if time.time() - timestamp < self.cache_duration:
                return sentiment

        # Get fresh news
        try:
            # Run API call in a thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            news = await loop.run_in_executor(
                None,
                lambda: self.newsapi.get_everything(
                    q=f"cryptocurrency {symbol.split('/')[0]}",
                    language='en',
                    sort_by='publishedAt',
                    page_size=10
                )
            )

            # Simple sentiment analysis based on title keywords
            positive_keywords = ['surge', 'jump', 'rise', 'bull', 'gain', 'high', 'breakout']
            negative_keywords = ['crash', 'drop', 'fall', 'bear', 'loss', 'low', 'decline']

            sentiment_score = 0
            for article in news['articles']:
                title = article['title'].lower()

                # Count positive and negative keywords
                positive_count = sum(1 for word in positive_keywords if word in title)
                negative_count = sum(1 for word in negative_keywords if word in title)

                sentiment_score += positive_count - negative_count

            # Normalize sentiment score
            if news['articles']:
                sentiment_score = sentiment_score / len(news['articles'])

            # Cache the result
            self.cache[symbol] = (time.time(), sentiment_score)

            return sentiment_score

        except Exception as e:
            print(f"Error fetching news for {symbol}: {str(e)}")
            return 0  # Neutral sentiment in case of error