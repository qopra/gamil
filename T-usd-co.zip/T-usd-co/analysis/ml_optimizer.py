import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from models import db, Trade, Signal
from datetime import datetime
import logging

logger = logging.getLogger(__name__) # Initialize logger

class MLOptimizer:
    def __init__(self):
        self.model = RandomForestClassifier(
            n_estimators=200,
            random_state=42,
            class_weight='balanced',
            max_depth=10,
            min_samples_split=5
        )
        self.scaler = StandardScaler()
        self.feature_importance = None
        self.trained = False

        # تحديث الأوقات عالية المخاطر بناءً على التحليل
        self.high_risk_hours = {0, 1, 2, 3, 4, 5, 6, 7}  # الساعات الأولى من اليوم
        self.optimal_hours = {18, 19, 20, 21, 22}  # أفضل ساعات التداول

        # تحديث أيام التداول المفضلة
        self.optimal_days = {'Friday', 'Thursday', 'Sunday'}
        self.high_risk_days = {'Saturday'}

    def prepare_features(self, signal_data, technical_indicators):
        current_hour = datetime.now().hour
        current_day = datetime.now().strftime('%A')

        features = []

        # المؤشرات الفنية مع أوزان محسنة
        features.extend([
            technical_indicators.get('rsi', 50) * 1.3,  # زيادة وزن RSI
            technical_indicators.get('macd', 0) * 1.5,
            technical_indicators.get('signal', 0),
            technical_indicators.get('ma_short', 0) * 1.2,  # زيادة وزن المتوسطات
            technical_indicators.get('ma_long', 0) * 1.2,
            technical_indicators.get('upper_bb', 0),
            technical_indicators.get('lower_bb', 0)
        ])

        # معلومات الإشارة
        features.append(1 if signal_data['direction'] == 'BUY' else 0)
        features.append(signal_data['strength'] * 1.4)  # زيادة وزن قوة الإشارة
        features.append(signal_data['confidence'])

        # معلومات التوقيت المحسنة
        features.append(1 if current_hour in self.high_risk_hours else 0)
        features.append(1 if current_hour in self.optimal_hours else 0)
        features.append(current_hour / 24.0)

        # معلومات اليوم
        features.append(1 if current_day in self.optimal_days else 0)
        features.append(1 if current_day in self.high_risk_days else 0)

        # مدة الصفقة المتوقعة
        features.append(1 if 18 <= current_hour <= 22 else 0)  # وقت مثالي للدخول

        return np.array(features).reshape(1, -1)

    def train_model(self):
        """تدريب النموذج على البيانات التاريخية مع تحسينات"""
        try:
            trades = Trade.query.all()
            signals = Signal.query.all()

            if not trades or not signals:
                logger.warning("No historical data available for ML training")
                return False

            X = []
            y = []

            for trade in trades:
                signal = next((s for s in signals if s.id == trade.signal_id), None)
                if signal:
                    hour = trade.entry_time.hour
                    features = [
                        trade.entry_price,
                        1 if signal.signal_type == 'BUY' else 0,
                        1 if hour in self.high_risk_hours else 0,
                        hour / 24.0,  # تطبيع ساعة اليوم
                    ]
                    X.append(features)
                    y.append(1 if trade.profit_amount > 0 else 0)

            if not X:
                logger.warning("No valid training data found")
                return False

            X = np.array(X)
            y = np.array(y)

            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
            X_train_scaled = self.scaler.fit_transform(X_train)

            self.model.fit(X_train_scaled, y_train)
            self.trained = True

            self.feature_importance = dict(zip(
                ['price', 'signal_type', 'high_risk_hour', 'hour_normalized'],
                self.model.feature_importances_
            ))

            X_test_scaled = self.scaler.transform(X_test)
            accuracy = self.model.score(X_test_scaled, y_test)

            logger.info(f"ML model trained successfully with accuracy: {accuracy:.2f}")
            return accuracy
        except Exception as e:
            logger.error(f"Error training ML model: {str(e)}")
            self.trained = False
            return False

    def predict_success(self, features):
        """التنبؤ بنجاح الإشارة مع المعايير المحسنة"""
        if not self.trained:
            return 0.5

        current_hour = datetime.now().hour
        current_day = datetime.now().strftime('%A')

        # تخفيض احتمالية الإشارات في الأوقات عالية المخاطر
        if current_hour in self.high_risk_hours:
            base_prob = self.model.predict_proba(features)[0][1]
            return base_prob * 0.6  # تخفيض أكبر للمخاطر

        # تخفيض احتمالية الإشارات في أيام السبت
        if current_day in self.high_risk_days:
            base_prob = self.model.predict_proba(features)[0][1]
            return base_prob * 0.5  # تخفيض كبير للمخاطر

        # زيادة احتمالية الإشارات في الأوقات المثالية
        if current_hour in self.optimal_hours and current_day in self.optimal_days:
            base_prob = self.model.predict_proba(features)[0][1]
            return min(base_prob * 1.2, 1.0)  # زيادة الثقة مع حد أقصى 100%

        features_scaled = self.scaler.transform(features)
        prob = self.model.predict_proba(features_scaled)[0][1]

        # زيادة عتبة الثقة المطلوبة
        if prob < 0.55:  # رفع العتبة من 0.45
            return 0.3

        return prob

    def analyze_failures(self):
        """تحليل أسباب الصفقات الخاسرة"""
        trades = Trade.query.filter(Trade.profit_amount < 0).all()
        signals = Signal.query.all()

        failure_analysis = {
            'total_failures': len(trades),
            'avg_loss': sum(t.profit_amount for t in trades) / len(trades) if trades else 0,
            'patterns': {
                'time_based': {},
                'signal_type': {'BUY': 0, 'SELL': 0}
            }
        }

        for trade in trades:
            signal = next((s for s in signals if s.id == trade.signal_id), None)
            if signal:
                # تحليل نمط الوقت
                hour = trade.entry_time.hour
                if hour not in failure_analysis['patterns']['time_based']:
                    failure_analysis['patterns']['time_based'][hour] = 0
                failure_analysis['patterns']['time_based'][hour] += 1

                # تحليل نوع الإشارة
                failure_analysis['patterns']['signal_type'][signal.signal_type] += 1

        return failure_analysis