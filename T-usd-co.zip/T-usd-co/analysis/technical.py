import numpy as np
import pandas as pd
from config import RSI_PERIOD, RSI_OVERBOUGHT, RSI_OVERSOLD, MA_SHORT, MA_LONG
import logging

logger = logging.getLogger(__name__)

class TechnicalAnalyzer:
    def calculate_rsi(self, closes):
        try:
            if len(closes) < RSI_PERIOD + 1:
                logger.warning(f"Insufficient data for RSI calculation. Need {RSI_PERIOD + 1} points, got {len(closes)}")
                return None

            returns = np.diff(closes)
            gains = returns.copy()
            losses = returns.copy()
            gains[gains < 0] = 0
            losses[losses > 0] = 0
            losses = abs(losses)

            avg_gain = np.mean(gains[:RSI_PERIOD])
            avg_loss = np.mean(losses[:RSI_PERIOD])

            if avg_loss == 0:
                return 100

            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            return rsi
        except Exception as e:
            logger.error(f"Error calculating RSI: {str(e)}")
            return None

    def calculate_macd(self, closes, fast=12, slow=26, signal=9):
        try:
            if len(closes) < slow + signal:
                logger.warning(f"Insufficient data for MACD calculation. Need {slow + signal} points, got {len(closes)}")
                return None, None

            closes_series = pd.Series(closes)
            exp1 = closes_series.ewm(span=fast, adjust=False).mean()
            exp2 = closes_series.ewm(span=slow, adjust=False).mean()
            macd = exp1 - exp2
            signal_line = macd.ewm(span=signal, adjust=False).mean()
            return macd.iloc[-1], signal_line.iloc[-1]
        except Exception as e:
            logger.error(f"Error calculating MACD: {str(e)}")
            return None, None

    def calculate_bollinger_bands(self, closes, period=20, std=2):
        try:
            if len(closes) < period:
                logger.warning(f"Insufficient data for Bollinger Bands calculation. Need {period} points, got {len(closes)}")
                return None, None, None

            closes_series = pd.Series(closes)
            ma = closes_series.rolling(window=period).mean()
            std_dev = closes_series.rolling(window=period).std()
            upper_band = ma + (std_dev * std)
            lower_band = ma - (std_dev * std)
            return upper_band.iloc[-1], ma.iloc[-1], lower_band.iloc[-1]
        except Exception as e:
            logger.error(f"Error calculating Bollinger Bands: {str(e)}")
            return None, None, None

    def calculate_moving_averages(self, closes):
        try:
            if len(closes) < MA_LONG:
                logger.warning(f"Insufficient data for MA calculation. Need {MA_LONG} points, got {len(closes)}")
                return None, None

            ma_short = pd.Series(closes).rolling(window=MA_SHORT).mean().iloc[-1]
            ma_long = pd.Series(closes).rolling(window=MA_LONG).mean().iloc[-1]
            return ma_short, ma_long
        except Exception as e:
            logger.error(f"Error calculating Moving Averages: {str(e)}")
            return None, None

    def analyze(self, ohlcv_data):
        try:
            closes = np.array([x[4] for x in ohlcv_data])

            # Calculate indicators
            rsi = self.calculate_rsi(closes)
            ma_short, ma_long = self.calculate_moving_averages(closes)
            macd, signal = self.calculate_macd(closes)
            upper_bb, middle_bb, lower_bb = self.calculate_bollinger_bands(closes)
            current_price = closes[-1]

            # Generate signals based on indicators
            signals = []

            # RSI signals
            if rsi is not None:
                if rsi > RSI_OVERBOUGHT:
                    signals.append(("RSI", "SELL", f"مؤشر القوة النسبية في منطقة التشبع: {rsi:.2f}"))
                elif rsi < RSI_OVERSOLD:
                    signals.append(("RSI", "BUY", f"مؤشر القوة النسبية في منطقة التشبع السفلي: {rsi:.2f}"))

            # Moving Average signals
            if ma_short is not None and ma_long is not None:
                if ma_short > ma_long:
                    signals.append(("MA", "BUY", "المتوسط المتحرك القصير تجاوز المتوسط الطويل"))
                elif ma_short < ma_long:
                    signals.append(("MA", "SELL", "المتوسط المتحرك القصير أقل من المتوسط الطويل"))

            # MACD signals
            if macd is not None and signal is not None:
                if macd > signal:
                    signals.append(("MACD", "BUY", "مؤشر MACD يشير إلى اتجاه صعودي"))
                elif macd < signal:
                    signals.append(("MACD", "SELL", "مؤشر MACD يشير إلى اتجاه هبوطي"))

            # Bollinger Bands signals
            if upper_bb is not None and lower_bb is not None:
                if current_price > upper_bb:
                    signals.append(("BB", "SELL", "السعر تجاوز النطاق العلوي لمؤشر Bollinger"))
                elif current_price < lower_bb:
                    signals.append(("BB", "BUY", "السعر أقل من النطاق السفلي لمؤشر Bollinger"))

            return signals
        except Exception as e:
            logger.error(f"Error in technical analysis: {str(e)}")
            return []