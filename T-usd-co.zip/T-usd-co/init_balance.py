from datetime import datetime
from models import db
from app import app
from utils.performance import PerformanceTracker

def initialize_balance():
    with app.app_context():
        db.create_all()
        
        tracker = PerformanceTracker()
        if tracker.initialize_account(initial_balance=200):
            print("تم إضافة رأس المال الأولي: $200")
        else:
            print("تم تهيئة رأس المال مسبقاً")

if __name__ == '__main__':
    initialize_balance()
