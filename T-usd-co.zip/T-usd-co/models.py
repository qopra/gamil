from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from shared_context import db

class AccountBalance(db.Model):
    __tablename__ = 'account_balance'

    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, nullable=False)
    balance = Column(Float, nullable=False)
    change = Column(Float, nullable=False)  # Amount changed in this update
    change_type = Column(String, nullable=False)  # 'initial', 'profit', 'loss'
    trade_id = Column(Integer, ForeignKey('trades.id'), nullable=True)

class Signal(db.Model):
    __tablename__ = 'signals'

    id = Column(Integer, primary_key=True)
    symbol = Column(String, nullable=False)
    signal_type = Column(String, nullable=False)  # BUY/SELL
    entry_price = Column(Float, nullable=False)
    timestamp = Column(DateTime, nullable=False)
    status = Column(String, default='open')  # open/closed
    trades = relationship("Trade", back_populates="signal")

class Trade(db.Model):
    __tablename__ = 'trades'

    id = Column(Integer, primary_key=True)
    signal_id = Column(Integer, ForeignKey('signals.id'))
    symbol = Column(String, nullable=False)
    entry_price = Column(Float, nullable=False)
    exit_price = Column(Float)
    position_size = Column(Float, nullable=False)  # Amount in USD
    profit_percentage = Column(Float)
    profit_amount = Column(Float)  # Actual profit/loss in USD
    entry_time = Column(DateTime, nullable=False)
    exit_time = Column(DateTime)
    signal = relationship("Signal", back_populates="trades")
    balance_updates = relationship("AccountBalance", backref="trade")

    @property
    def duration(self):
        if self.exit_time:
            return self.exit_time - self.entry_time
        return None