def format_signal_message(pair, signal):
    """Format the signal message for Telegram"""

    # Emoji indicators
    direction_emoji = {
        'BUY': '🟢',
        'SELL': '🔴',
        'NEUTRAL': '⚪'
    }

    strength_indicators = '🔥' * int(signal['strength']) if signal['strength'] > 0 else '➖'

    message = (
        f"💹 تحليل {pair}\n\n"
        f"{direction_emoji[signal['direction']]} الإشارة: {signal['direction']}\n"
        f"💪 القوة: {strength_indicators}\n"
    )

    if 'confidence' in signal and signal['confidence'] > 0:
        message += f"📊 مستوى الثقة: {signal['confidence']:.1f}%\n"

    if signal.get('target_price'):
        message += f"🎯 هدف الربح: {signal['target_price']:.2f}\n"

    if signal.get('stop_loss'):
        message += f"🛑 وقف الخسارة: {signal['stop_loss']:.2f}\n"

    message += f"\n📝 الأسباب:\n"
    for reason in signal['reasons']:
        message += f"• {reason}\n"

    message += "\n⚠️ تنبيه: هذه الإشارات للأغراض التعليمية فقط وليست نصيحة مالية"

    return message