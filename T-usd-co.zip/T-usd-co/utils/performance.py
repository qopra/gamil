from datetime import datetime, timedelta
from models import db, Signal, Trade, AccountBalance

class PerformanceTracker:
    def __init__(self):
        # Get latest balance
        last_balance = AccountBalance.query.order_by(AccountBalance.timestamp.desc()).first()
        self.current_balance = last_balance.balance if last_balance else 0

    def initialize_account(self, initial_balance=200):
        """Initialize account with starting balance"""
        if not AccountBalance.query.first():
            balance = AccountBalance(
                timestamp=datetime(2025, 1, 1),
                balance=initial_balance,
                change=initial_balance,
                change_type='initial'
            )
            db.session.add(balance)
            db.session.commit()
            self.current_balance = initial_balance
            return True
        return False

    def calculate_position_size(self, symbol):
        """Calculate safe position size based on current balance"""
        # Use 20% of balance per trade for now
        return min(self.current_balance * 0.2, self.current_balance)

    def add_signal(self, symbol, signal_type, entry_price, timestamp):
        signal = Signal(
            symbol=symbol,
            signal_type=signal_type,
            entry_price=entry_price,
            timestamp=timestamp,
            status='open'
        )
        db.session.add(signal)
        db.session.commit()
        return signal

    def update_trade(self, symbol, exit_price, timestamp):
        signal = Signal.query.filter_by(
            symbol=symbol, 
            status='open'
        ).order_by(Signal.timestamp.desc()).first()

        if signal:
            # Calculate position size based on current balance
            position_size = self.calculate_position_size(symbol)

            # Calculate profit/loss
            price_change_pct = (exit_price - signal.entry_price) / signal.entry_price
            if signal.signal_type == 'SELL':
                price_change_pct = -price_change_pct

            profit_amount = position_size * price_change_pct

            trade = Trade(
                signal_id=signal.id,
                symbol=symbol,
                entry_price=signal.entry_price,
                exit_price=exit_price,
                position_size=position_size,
                profit_percentage=price_change_pct * 100,
                profit_amount=profit_amount,
                entry_time=signal.timestamp,
                exit_time=timestamp
            )

            # Update account balance
            new_balance = self.current_balance + profit_amount
            balance_update = AccountBalance(
                timestamp=timestamp,
                balance=new_balance,
                change=profit_amount,
                change_type='profit' if profit_amount > 0 else 'loss',
                trade_id=trade.id
            )

            signal.status = 'closed'
            db.session.add(trade)
            db.session.add(balance_update)
            db.session.commit()

            self.current_balance = new_balance

    def get_performance_report(self, start_date=None):
        if not start_date:
            start_date = datetime(2025, 1, 1)

        trades = Trade.query.filter(Trade.entry_time >= start_date).all()
        balances = AccountBalance.query.filter(
            AccountBalance.timestamp >= start_date
        ).order_by(AccountBalance.timestamp).all()

        if not trades:
            return "لا توجد صفقات مكتملة في هذه الفترة"

        initial_balance = balances[0].balance if balances else 200
        current_balance = balances[-1].balance if balances else initial_balance
        total_profit = current_balance - initial_balance

        total_trades = len(trades)
        profitable_trades = len([t for t in trades if t.profit_amount > 0])
        win_rate = (profitable_trades / total_trades) * 100 if total_trades > 0 else 0

        # Calculate performance by symbol
        trades_by_symbol = {}
        for trade in trades:
            if trade.symbol not in trades_by_symbol:
                trades_by_symbol[trade.symbol] = []
            trades_by_symbol[trade.symbol].append(trade)

        symbol_performance = []
        for symbol, symbol_trades in trades_by_symbol.items():
            symbol_profit = sum(t.profit_amount for t in symbol_trades)
            symbol_performance.append(
                f"{symbol}: {len(symbol_trades)} صفقات - الربح: ${symbol_profit:.2f}"
            )

        best_trade = max(trades, key=lambda t: t.profit_amount)
        worst_trade = min(trades, key=lambda t: t.profit_amount)

        report = (
            "📊 تقرير الأداء\n\n"
            f"📅 منذ: {start_date.strftime('%Y-%m-%d')}\n"
            f"💰 رأس المال الأولي: ${initial_balance:.2f}\n"
            f"💵 الرصيد الحالي: ${current_balance:.2f}\n"
            f"📈 إجمالي الربح/الخسارة: ${total_profit:.2f} ({(total_profit/initial_balance*100):.1f}%)\n\n"
            f"📊 إحصائيات الصفقات:\n"
            f"💰 إجمالي الصفقات: {total_trades}\n"
            f"✅ الصفقات الرابحة: {profitable_trades}\n"
            f"📈 نسبة النجاح: {win_rate:.2f}%\n\n"
            "📊 الأداء حسب العملة:\n"
        )

        for perf in symbol_performance:
            report += f"• {perf}\n"

        report += (
            f"\n🏆 أفضل صفقة: {best_trade.symbol} (${best_trade.profit_amount:.2f})\n"
            f"⚠️ أسوأ صفقة: {worst_trade.symbol} (${worst_trade.profit_amount:.2f})\n\n"
            "⚠️ تنبيه: هذه الإشارات للأغراض التعليمية فقط وليست نصيحة مالية"
        )

        return report